local QRDrawNode = class("QRDrawNode",function()
	return display.newDrawNode()
end)
local qrencode = require("script.public.qrencode")
function QRDrawNode:ctor()
	
end

function QRDrawNode:setQRString(str)
	self:clear()
	local ok, tab_or_message = qrencode.qrcode(str)
	if not ok then
	    print(tab_or_message)
	else
		local black = cc.c4f(0,0,0,1)
		local white = cc.c4f(1,1,1,1)
		local width = 10
		local height=  width
		for i,v in ipairs(tab_or_message) do
			local count = #v
			for j,colorFlag in ipairs(v) do
				local x = (i-1) * width
				local y = (count - j) * height
				local points = {
			        {x,y},
			        {x + width, y},
			        {x + width, y + height},
			        {x, y + height}
			    }
			    local color = white
			    if colorFlag > 0 then color = black end
			    local params = {
			    	fillColor = color, 
			    	borderColor = cc.c4f(0,1,0,1), 
			    	borderWidth = 0
			    }
				display.newPolygon(points, params, self)
			end
		end
	end
end

function QRDrawNode.createQRDrawNode(str)
	local node = QRDrawNode.new()
	if str then
		node:setQRString(str)
	end
	return node
end

return QRDrawNode